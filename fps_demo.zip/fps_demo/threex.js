module.exports = {
    getApp() {
        return getApp()
    },
    getCurrentPages() {
        return getCurrentPages()
    },
    wx_request() {
        return wx.request
    }
}