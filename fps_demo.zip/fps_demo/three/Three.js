const THREE = requirePlugin('ThreeX');
module.exports = THREE