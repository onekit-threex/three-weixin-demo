// app.js
App({
	onekit_path :"https://onekit.cn/examples/",
})
